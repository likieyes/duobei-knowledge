package data.iFace;

public interface userFace {
	public int QueryUser(String userName,String userPass);
	public String getErrString();
}
