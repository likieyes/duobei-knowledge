package Spring.IFace;

public interface userServiceIFace {
	public int QueryUser(String userName,String userPass);
	public String getErrString();
}
